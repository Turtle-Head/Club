# Portfolio
**Portfolio of work**
The project is to mock up a portfolio in a grid based pattern.

It has been *updated* with my own work to show off what I have done and provide easy access to projects as an ongoing 
and organic entity.

**Sept 19/15** 
- Updated links to my own work after publishing the repositories on Github
- Added a picture of the Bugged game for Project 3
